
document.getElementById('runScript').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      files: ['content.js']
    });
  });
});

document.getElementById("getCookie").addEventListener("click", () => {
  chrome.cookies.get({ url: "https://grnd.gg", name: "connect.sid" }, (cookie) => {
    const output = document.getElementById("output");

    if (cookie && cookie.value) {
      output.textContent = cookie.value;
      navigator.clipboard.writeText(cookie.value)
        .then(() => {
          output.classList.add("copied");
          setTimeout(() => output.classList.remove("copied"), 1500);
        })
        .catch(err => console.error("Ошибка копирования:", err));
    } else {
      output.textContent = "Кука connect.sid не найдена.";
    }
  });
});

document.getElementById("output").addEventListener("click", () => {
  const text = document.getElementById("output").textContent;
  if (text && text !== "—") {
    navigator.clipboard.writeText(text);
  }
});
